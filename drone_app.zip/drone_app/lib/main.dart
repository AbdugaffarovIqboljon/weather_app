import 'package:drone_app/app.dart';
import 'package:flutter/material.dart';

void main() => runApp(const App());
