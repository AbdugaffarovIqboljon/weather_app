import 'package:drone_app/services/colors.dart';
import 'package:flutter/material.dart';
import '../services/icons.dart';
import '../services/images.dart';
import '../services/strings.dart';
import '../views/header_horizontal_containers.dart';


class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    double x = MediaQuery.of(context).size.width;
    double y = MediaQuery.of(context).size.height;
    return Scaffold(
      backgroundColor: CustomColors.oxFF16182C,
      body: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(height: y * 0.075),

            /// #AppBar
            Row(
              children: [
                SizedBox(width: x * 0.05),
                const Image(
                  image: CustomIcons.timeProgress,
                  height: 33,
                  width: 33,
                ),
                SizedBox(width: x * 0.05),
                const Text.rich(
                  TextSpan(
                    children: [
                      TextSpan(
                        text: CustomStrings.drone,
                        style: TextStyle(
                          fontSize: 20,
                          fontFamily: 'Circular Std',
                          fontWeight: FontWeight.w500,
                          color: CustomColors.oxFF33BBF5,
                        ),
                      ),
                      TextSpan(
                        text: CustomStrings.kart,
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 20,
                          fontFamily: 'Circular Std',
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(width: x * 0.42),
                const Image(
                    image: CustomIcons.userCircle, height: 33, width: 33),
              ],
            ),
            SizedBox(height: y * 0.04),

            /// #Horizontal Containers
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: const [
                  /// First Horizontal Container
                  HorizontalContainersWidget(
                    image: Image(image: CustomImages.djAir2S),
                    headerText: CustomStrings.djiAir2S,
                    descriptionText: CustomStrings.djiAir2SDescription,
                  ),

                  /// Second Horizontal Container
                  HorizontalContainersWidget(
                    image: Image(image: CustomImages.djMatric30Series),
                    headerText: CustomStrings.djiMatrice30Series,
                    descriptionText:
                        CustomStrings.djiMatrice30SeriesDescription,
                  ),
                  SizedBox(width: 10),
                ],
              ),
            ),

            /// #Header Text
            SizedBox(height: y * 0.03),
            Row(
              children: [
                SizedBox(width: x * 0.06),
                const Text(
                  CustomStrings.newHeaderText,
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 27,
                    fontFamily: 'Circular Std',
                    fontWeight: FontWeight.w700,
                  ),
                ),
                SizedBox(width: x * 0.03),
                const Image(image: CustomIcons.bubble, height: 34, width: 34),
              ],
            ),
            // SizedBox(height: y * 0.03),
            /// #Second Header Text
            Row(
              children: [
                SizedBox(width: x * 0.06),
                const Text(
                  CustomStrings.arrivals,
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 27,
                    fontFamily: 'Circular Std',
                    fontWeight: FontWeight.w700,
                  ),
                ),
                SizedBox(width: x * 0.58),
                const Image(image: CustomIcons.full, height: 34, width: 34),
              ],
            ),
            const SizedBox(height: 20),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  SizedBox(width: x * 0.05),

                  /// #Sub Drone First Images
                  SizedBox(height: y * 0.03),
                  Container(
                    width: 169,
                    height: 280,
                    decoration: ShapeDecoration(
                      gradient: LinearGradient(
                        begin: const Alignment(0.00, -1.00),
                        end: const Alignment(0, 1),
                        colors: [
                          CustomColors.oxFF292D4E,
                          CustomColors.oxFF292D4E,
                          CustomColors.oxFF292D4E,
                          CustomColors.oxFF424161,
                        ],
                      ),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(22),
                      ),
                    ),
                    child: Column(
                      children: [
                        SizedBox(height: y * 0.025),
                        const Image(
                          image: CustomIcons.djiLogo,
                          width: 45,
                          height: 26,
                        ),
                        SizedBox(height: y * 0.025),
                        Transform.scale(
                          scale: 1.2,
                          child: const Image(
                            image: CustomImages.djMavicRed,
                          ),
                        ),
                      ],
                    ),
                  ),

                  /// #Sub Drone Second Image
                  SizedBox(width: x * 0.05),
                  Container(
                    width: 169,
                    height: 280,
                    decoration: ShapeDecoration(
                      gradient: LinearGradient(
                        begin: const Alignment(0.00, -1.00),
                        end: const Alignment(0, 1),
                        colors: [
                          CustomColors.oxFF292D4E,
                          CustomColors.oxFF292D4E,
                          CustomColors.oxFF292D4E,
                          CustomColors.oxFF424161,
                        ],
                      ),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(22),
                      ),
                    ),
                    child: Column(
                      children: [
                        SizedBox(height: y * 0.025),
                        const Image(
                          image: CustomIcons.djiLogo,
                          width: 45,
                          height: 26,
                        ),
                        SizedBox(height: y * 0.07),
                        Transform.scale(
                          scaleX: 2.5,
                          scaleY: 2.3,
                          child: const Image(image: CustomImages.djMavicSecond),
                        ),
                      ],
                    ),
                  ),

                  /// #Sub Drone Third Image
                  SizedBox(width: x * 0.05),
                  Container(
                    width: 169,
                    height: 280,
                    decoration: ShapeDecoration(
                      gradient: LinearGradient(
                        begin: const Alignment(0.00, -1.00),
                        end: const Alignment(0, 1),
                        colors: [
                          CustomColors.oxFF292D4E,
                          CustomColors.oxFF292D4E,
                          CustomColors.oxFF292D4E,
                          CustomColors.oxFF424161,
                        ],
                      ),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(22),
                      ),
                    ),
                    child: Column(
                      children: [
                        SizedBox(height: y * 0.025),
                        const Image(
                          image: CustomIcons.djiLogo,
                          width: 45,
                          height: 26,
                        ),
                        SizedBox(height: y * 0.075),
                        Transform.scale(
                          scaleX: 2.4,
                          scaleY: 2.2,
                          child:
                              const Image(image: CustomImages.djMatric30Series),
                        ),
                      ],
                    ),
                  ),

                  SizedBox(width: x * 0.05),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
