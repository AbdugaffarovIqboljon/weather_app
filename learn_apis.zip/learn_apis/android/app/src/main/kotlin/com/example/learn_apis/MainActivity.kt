package com.example.learn_apis

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
