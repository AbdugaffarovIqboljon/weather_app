import 'package:flutter/material.dart';
import 'package:learn_apis/pages/home_page.dart';
import 'package:learn_apis/pages/home_page_second_lesson.dart';
import 'package:learn_apis/pages/hometask_fourth.dart';
import 'package:learn_apis/pages/homework_task_one.dart';
import 'package:learn_apis/pages/homework_task_second.dart';
import 'package:learn_apis/pages/product_page.dart';

class LearnHttp extends StatelessWidget {
  const LearnHttp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      home: Task1(),
    );
  }
}
