class Albums {
  int id;
  String title;
  int userId;

  Albums({
    required this.id,
    required this.title,
    required this.userId,
  });

  factory Albums.fromJson(Map<String, dynamic> json) {
    return Albums(
      id: json["id"],
      title: json["title"],
      userId: json["userId"],
    );
  }
}