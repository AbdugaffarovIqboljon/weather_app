class Movie {
  int id;
  String movie;
  double rating;

  Movie({required this.id, required this.rating, required this.movie});

  factory Movie.fromJson(Map<String, dynamic> json) {
    return Movie(
      id: json["id"],
      rating: json["rating"],
      movie: json["movie"],
    );
  }
}
