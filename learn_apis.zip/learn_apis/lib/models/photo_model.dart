class Photo {
  int albumId;
  int id;
  String title;
  String url;
  String thumbnailUrl;

  Photo({
    required this.title,
    required this.id,
    required this.url,
    required this.albumId,
    required this.thumbnailUrl,
  });

  factory Photo.fromJson(Map<String, dynamic> json) {
    return Photo(
      title: json["title"],
      id: json["id"],
      url: json["url"],
      albumId: json["albumId"],
      thumbnailUrl: json["thumbnailUrl"],
    );
  }
}
