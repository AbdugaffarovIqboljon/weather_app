class Product {
  int id;
  String title;
  double price;
  String description;
  String category;
  String image;


  Product({
    required this.id,
    required this.title,
    required this.description,
    required this.price,
    required this.image,
    required this.category,

  });

  factory Product.fromJson(Map<String, dynamic> json) {
    return Product(
      id: json["id"],
      title: json["title"],
      description: json["description"],
      price: json["price"],
      image: json["image"],
      category: json["category"],
    );
  }
}
