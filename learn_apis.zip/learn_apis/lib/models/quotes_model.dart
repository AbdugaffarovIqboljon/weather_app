class Quotes {
  String author;
  String quote;
  int id;

  Quotes({
    required this.author,
    required this.quote,
    required this.id,
  });

  factory Quotes.fromJson(Map<String, dynamic> json) {
    return Quotes(
      author: json["author"],
      quote: json["quote"],
      id: json["id"],
    );
  }
}
