class SmallProduct {
  int id;
  String name;
  String price;
  String description;

  SmallProduct({
    required this.id,
    required this.name,
    required this.description,
    required this.price,
  });

  factory SmallProduct.fromJson(Map<String, dynamic> json) {
    return SmallProduct(
      id: json["id"],
      name: json["name"],
      description: json["description"],
      price: json["price"],
    );
  }
}
