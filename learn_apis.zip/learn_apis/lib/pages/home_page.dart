import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart';

import '../models/album_model.dart';
import '../models/photo_model.dart';
import '../services/network_service.dart';

/// #Snapshot 1
// class HomePage extends StatefulWidget {
//   const HomePage({Key? key}) : super(key: key);
//
//   @override
//   State<HomePage> createState() => _HomePageState();
// }
//
// class _HomePageState extends State<HomePage> {
//   String text = "NO DATA";
//   final path = "https://jsonplaceholder.typicode.com/posts";
//
//   /// #InitState
//   @override
//   void initState() {
//     super.initState();
//     getDataFromCloud();
//   }
//
//   /// #Getting Data From Cloud
//   void getDataFromCloud() {
//     Uri url = Uri.parse(path);
//     get(url).then((response) {
//       debugPrint("body: ${response.body}\n");
//       debugPrint("statusCode: ${response.statusCode}\n");
//       debugPrint("bodyBytes: ${response.bodyBytes}\n");
//       debugPrint("headers: ${response.headers}\n");
//       debugPrint("request: ${response.request}\n");
//       debugPrint("reasonPhrase: ${response.reasonPhrase}\n");
//       debugPrint("contentLength: ${response.contentLength}\n");
//       debugPrint("isRedirect: ${response.isRedirect}\n");
//       debugPrint("persistentConnection: ${response.persistentConnection}\n");
//     });
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: Center(
//         child: Text(
//           text,
//           style: const TextStyle(
//             fontSize: 16,
//             color: Colors.black,
//             fontWeight: FontWeight.w500,
//           ),
//         ),
//       ),
//     );
//   }
// }

/// #Snapshot 2
// class HomePage extends StatefulWidget {
//   const HomePage({Key? key}) : super(key: key);
//
//   @override
//   State<HomePage> createState() => _HomePageState();
// }
//
// class _HomePageState extends State<HomePage> {
//   String text = "NO DATA";
//   final path = "https://jsonplaceholder.typicode.com/posts/1";
//
//   /// #InitState
//   @override
//   void initState() {
//     super.initState();
//     getDataFromCloud();
//   }
//
//   /// #Getting Data From Cloud
//   void getDataFromCloud() {
//     Uri url = Uri.parse(path);
//     get(url).then((response) {
//       if (response.statusCode == 200) {
//         text = response.body;
//       } else {
//         text = "Something error";
//       }
//       setState(() {});
//     });
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: Center(
//         child: Text(
//           text,
//           style: const TextStyle(
//             fontSize: 16,
//             color: Colors.black,
//             fontWeight: FontWeight.w500,
//           ),
//         ),
//       ),
//     );
//   }
// }

/// #Snapshot 3
// class HomePage extends StatefulWidget {
//   const HomePage({Key? key}) : super(key: key);
//
//   @override
//   State<HomePage> createState() => _HomePageState();
// }
//
// class _HomePageState extends State<HomePage> {
//   String text = "NO DATA";
//
//   /// #Domain
//   final domain = "jsonplaceholder.typicode.com";
//
//   /// #Base Url
//   final api = "/posts";
//
//   @override
//   void initState() {
//     getDataFromCloud(api: api, id: 1);
//     super.initState();
//   }
//
//   void getDataFromCloud({
//     required String api,
//     String baseUrl = "jsonplaceholder.typicode.com",
//     int? id,
//   }) {
//     Uri url = Uri.https(baseUrl, "$api${id != null ? "/$id" : ""}");
//
//     get(url).then((response) {
//       if (response.statusCode == 200) {
//         text = response.body;
//       } else {
//         text = "Something Error";
//       }
//       setState(() {});
//     });
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: Center(
//         child: Text(
//           text,
//           style: const TextStyle(
//             fontWeight: FontWeight.w500,
//             fontSize: 18,
//             color: Colors.black,
//           ),
//         ),
//       ),
//     );
//   }
// }

/// #Snapshot 4
// class HomePage extends StatefulWidget {
//   const HomePage({Key? key}) : super(key: key);
//
//   @override
//   State<HomePage> createState() => _HomePageState();
// }
//
// class _HomePageState extends State<HomePage> {
//   String text = "No data";
//
//   /// #Domain
//   final domain = "jsonplaceholder.typicode.com";
//
//   /// #Base Url
//   final api = "/posts";
//
//   @override
//   void initState() {
//     getDataFromCloud(api: api, id: 1);
//     super.initState();
//   }
//
//   void getDataFromCloud({
//     required String api,
//     String baseUrl = "jsonplaceholder.typicode.com",
//     int? id,
//   }) {
//     Uri url = Uri.https(baseUrl, "$api${id != null ? "/$id" : ""}");
//
//     get(url).then((response) {
//       if (response.statusCode == 200) {
//         text = response.body;
//       } else {
//         text = "Something Error";
//       }
//
//       /// #For Console
//       final result = jsonDecode(text);
//       debugPrint((result is Map).toString());
//       debugPrint(result.toString());
//       debugPrint("title: ${result["title"]}");
//
//       setState(() {});
//     });
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: Center(
//         child: Text(
//           text,
//           style: const TextStyle(
//             fontWeight: FontWeight.w500,
//             fontSize: 18,
//             color: Colors.black,
//           ),
//         ),
//       ),
//     );
//   }
// }

/// #Snapshot 5
// class HomePage extends StatefulWidget {
//   const HomePage({Key? key}) : super(key: key);
//
//   @override
//   State<HomePage> createState() => _HomePageState();
// }
//
// class _HomePageState extends State<HomePage> {
//   String text = "No data";
//   String body = "No body";
//
//   /// #Domain
//   final domain = "jsonplaceholder.typicode.com";
//
//   /// #Base Url
//   final api = "/posts";
//
//   @override
//   void initState() {
//     getDataFromCloud(api: api, id: 1);
//     super.initState();
//   }
//
//   void getDataFromCloud({
//     required String api,
//     String baseUrl = "jsonplaceholder.typicode.com",
//     int? id,
//   }) {
//     Uri url = Uri.https(baseUrl, "$api${id != null ? "/$id" : ""}");
//
//     get(url).then((response) {
//       if (response.statusCode == 200) {
//         final result = jsonDecode(response.body);
//         text = result["title"];
//         body = result["body"];
//       } else {
//         text = "Something Error";
//       }
//
//       setState(() {});
//     });
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: SafeArea(
//         minimum: const EdgeInsets.symmetric(horizontal: 12),
//         child: Center(
//           child: Text(
//             text,
//             style: const TextStyle(
//               fontWeight: FontWeight.w500,
//               fontSize: 18,
//               color: Colors.black,
//             ),
//           ),
//         ),
//       ),
//     );
//   }
// }

/// #Snapshot 6
// class HomePage extends StatefulWidget {
//   const HomePage({Key? key}) : super(key: key);
//
//   @override
//   State<HomePage> createState() => _HomePageState();
// }
//
// class _HomePageState extends State<HomePage> {
//   Todo? todo;
//   final domain = "jsonplaceholder.typicode.com";
//   final api = "/todos";
//
//   @override
//   void initState() {
//     getDataFromCloud(api: api, id: 1);
//     super.initState();
//   }
//
//   void getDataFromCloud({
//     required String api,
//     String baseUrl = "jsonplaceholder.typicode.com",
//     int? id,
//   }) {
//     Uri url = Uri.https(baseUrl, "$api${id != null ? "/$id" : ""}");
//
//     get(url).then((response) {
//       if (response.statusCode == 200) {
//         final result = jsonDecode(response.body);
//         todo = Todo(
//           id: 1,
//           todo: result["title"],
//           completed: result["completed"],
//           userId: result["userId"],
//         );
//       }
//       setState(() {});
//     });
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: SafeArea(
//         minimum: const EdgeInsets.symmetric(horizontal: 12),
//         child: Center(
//           child: todo != null
//               ? ListTile(
//                   title: Text(todo!.todo),
//                   subtitle: Text(todo!.completed.toString()),
//                 )
//               : const Text("No Data"),
//         ),
//       ),
//     );
//   }
// }

/// #Snapshot 7
// class HomePage extends StatefulWidget {
//   const HomePage({Key? key}) : super(key: key);
//
//   @override
//   State<HomePage> createState() => _HomePageState();
// }
//
// class _HomePageState extends State<HomePage> {
//   Todo? todo;
//   final domain = "dummyjson.com";
//   final api = "/todos";
//
//   @override
//   void initState() {
//     super.initState();
//     getDataFromCloud(api: api, id: 1);
//   }
//
//   void getDataFromCloud({
//     required String api,
//     String baseUrl = "dummyjson.com",
//     int? id,
//   }) {
//     Uri url = Uri.https(baseUrl, "$api${id != null ? "/$id" : ""}");
//
//     get(url).then((response) {
//       if (response.statusCode == 200) {
//         final result = jsonDecode(response.body);
//         todo = Todo.fromJson(result);
//       }
//       setState(() {});
//     });
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: SingleChildScrollView(
//         child: SafeArea(
//           child: Column(
//             mainAxisAlignment: MainAxisAlignment.center,
//             children: [
//               const SizedBox(height: 80),
//               Center(
//                 child: todo != null
//                     ? ListTile(
//                         title: Text(todo!.todo),
//                         subtitle: Text(todo!.completed.toString()),
//                       )
//                     : const Text("NO DATA"),
//               ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }
// }
//
// /// Snapshot 8
// // class HomePage extends StatefulWidget {
// //   const HomePage({Key? key}) : super(key: key);
// //
// //   @override
// //   State<HomePage> createState() => _HomePageState();
// // }
// //
// // class _HomePageState extends State<HomePage> {
// //   List<Post> list = [];
// //   final domain = "jsonplaceholder.typicode.com";
// //   final api = "/posts";
// //
// //   @override
// //   void initState() {
// //     super.initState();
// //     getDataFromCloud(api: api);
// //   }
// //
// //   void getDataFromCloud(
// //       {required String api,
// //         String baseUrl = "jsonplaceholder.typicode.com",
// //         int? id}) {
// //     Uri url = Uri.https(baseUrl, "$api${id != null ? "/$id" : ""}");
// //     get(url).then((response) {
// //       if (response.statusCode == 200) {
// //         final List result = jsonDecode(response.body);
// //         for (int i = 0; i < result.length; i++) {
// //           debugPrint(result[i].toString());
// //           final post = Post.fromJson(result[i]);
// //           list.add(post);
// //         }
// //       }
// //       setState(() {});
// //     });
// //   }
// //
// //   @override
// //   Widget build(BuildContext context) {
// //     return Scaffold(
// //       appBar: AppBar(
// //         title: const Text("User posts"),
// //       ),
// //       body: ListView.builder(
// //         itemCount: list.length,
// //         itemBuilder: (_, index) {
// //           final post = list[index];
// //           return Card(
// //             child: ListTile(
// //               leading: Container(
// //                 padding: const EdgeInsets.all(10),
// //                 decoration: BoxDecoration(
// //                   shape: BoxShape.circle,
// //                   color: Colors.primaries[index % Colors.primaries.length],
// //                 ),
// //                 child: Text(post.userId.toString(), style: const TextStyle(color: Colors.white, fontSize: 16),),
// //               ),
// //               title: Text(post.title),
// //               subtitle: Text(post.body),
// //             ),
// //           );
// //         },
// //       ),
// //     );
// //   }
// // }
//
// /// #Snapshot
// // class HomePage extends StatefulWidget {
// //   const HomePage({Key? key}) : super(key: key);
// //
// //   @override
// //   State<HomePage> createState() => _HomePageState();
// // }
// //
// // class _HomePageState extends State<HomePage> {
// //   List<Albums> list = [];
// //   final domain = "jsonplaceholder.typicode.com";
// //   final api = "/albums";
// //
// //   @override
// //   void initState() {
// //     super.initState();
// //     getDataFromCloud(api: api);
// //   }
// //
// //   void getDataFromCloud({
// //     required String api,
// //     String baseUrl = "jsonplaceholder.typicode.com",
// //     int? id,
// //   }) {
// //     Uri url = Uri.https(baseUrl, "$api${id != null ? "/$id" : ""}");
// //     get(url).then((response) {
// //       if (response.statusCode == 200) {
// //         final List result = jsonDecode(response.body);
// //         list = result.map((json) => Albums.fromJson(json)).toList();
// //       }
// //       setState(() {});
// //     });
// //   }
// //
// //   @override
// //   Widget build(BuildContext context) {
// //     return Scaffold(
// //       appBar: AppBar(
// //         title: const Text("User posts"),
// //       ),
// //       body: ListView.builder(
// //         itemCount: list.length,
// //         itemBuilder: (_, index) {
// //           final album = list[index];
// //           return Card(
// //             child: ListTile(
// //               leading: Container(
// //                 padding: const EdgeInsets.all(10),
// //                 decoration: BoxDecoration(
// //                   shape: BoxShape.circle,
// //                   color: Colors.primaries[index % Colors.primaries.length],
// //                 ),
// //                 child: Text(
// //                   album.userId.toString(),
// //                   style: const TextStyle(color: Colors.white, fontSize: 16),
// //                 ),
// //               ),
// //               title: Text(album.title),
// //               subtitle: Text(album.id.toString()),
// //             ),
// //           );
// //         },
// //       ),
// //     );
// //   }
// // }
//
// /// #Albums
// class HomePage2 extends StatefulWidget {
//   const HomePage2({Key? key}) : super(key: key);
//
//   @override
//   State<HomePage2> createState() => _HomePageState2();
// }
//
// class _HomePageState2 extends State<HomePage2> {
//   List<Albums> list = [];
//   final domain = "jsonplaceholder.typicode.com";
//   final api = "/albums";
//
//   @override
//   void initState() {
//     super.initState();
//     fetchAlbum();
//   }
//
//   void fetchAlbum() async {
//     String data = await getMethod(api: api);
//     list = parseAlbumList(data);
//     setState(() {});
//   }
//
//   Future<String> getMethod({
//     required String api,
//     String baseUrl = "jsonplaceholder.typicode.com",
//     int? id,
//   }) async {
//     Uri url = Uri.https(baseUrl, "$api${id != null ? "/$id" : ""}");
//     final response = await get(url);
//
//     if (response.statusCode == 200) {
//       return response.body;
//     }
//
//     throw Exception("Network Exception");
//   }
//
//   List<Albums> parseAlbumList(String data) {
//     final List result = jsonDecode(data);
//     final items = result.map((json) => Albums.fromJson(json)).toList();
//     return items;
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: const Text("User posts"),
//       ),
//       body: ListView.builder(
//         itemCount: list.length,
//         itemBuilder: (_, index) {
//           final albums = list[index];
//           return Card(
//             child: ListTile(
//               leading: Container(
//                 padding: const EdgeInsets.all(10),
//                 decoration: BoxDecoration(
//                   shape: BoxShape.circle,
//                   color: Colors.primaries[index % Colors.primaries.length],
//                 ),
//                 child: Text(
//                   albums.title,
//                   style: const TextStyle(color: Colors.white, fontSize: 16),
//                 ),
//               ),
//               title: Text(albums.userId.toString()),
//             ),
//           );
//         },
//       ),
//     );
//   }
// }
//
// /// #Photos
// class HomePage extends StatefulWidget {
//   const HomePage({Key? key}) : super(key: key);
//
//   @override
//   State<HomePage> createState() => _HomePageState();
// }
//
// class _HomePageState extends State<HomePage> {
//   List<Photo> list = [];
//
//
//   @override
//   void initState() {
//     super.initState();
//     fetchData();
//   }
//
//   void fetchData() async {
//     String? data = await Network.methodGet(api: Network.apiPhotos);
//     if(data != null) {
//       list = Network.parseAlbumList(data);
//       setState(() {});
//     } else {
//       ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Something error! Check your network connection")));
//     }
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: const Text("User posts"),
//       ),
//       body: ListView.builder(
//         itemCount: list.length,
//         itemBuilder: (_, index) {
//           final photos = list[index];
//           return Card(
//             child: ListTile(
//               leading: Container(
//                 padding: const EdgeInsets.all(10),
//                 decoration: BoxDecoration(
//                   shape: BoxShape.circle,
//                   color: Colors.primaries[index % Colors.primaries.length],
//                 ),
//                 child: Text(photos.albumId.toString(), style: const TextStyle(color: Colors.white, fontSize: 16),),
//               ),
//               title: Text(photos.title),
//               subtitle: Text(photos.url.toString()),
//             ),
//           );
//         },
//       ),
//     );
//   }
// }