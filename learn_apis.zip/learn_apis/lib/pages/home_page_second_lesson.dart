import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart';
import '../models/post_model.dart';
import '../services/network_service.dart';

/// #Snapshot 1
// class HomePageSecondLesson extends StatefulWidget {
//   const HomePageSecondLesson({Key? key}) : super(key: key);
//
//   @override
//   State<HomePageSecondLesson> createState() => _HomePageSecondLessonState();
// }
//
// class _HomePageSecondLessonState extends State<HomePageSecondLesson> {
//   Post? post;
//   Product? product;
//   final domain = "fakestoreapi.com";
//   final api = "/products";
//   bool isLoading = false;
//
//   @override
//   void initState() {
//     super.initState();
//     getDataFromCloud(api: api, id: 1);
//   }
//
//   void getDataFromCloud({
//     required String api,
//     String baseUrl = "fakestoreapi.com",
//     int? id,
//   }) {
//     Uri url = Uri.https(baseUrl, "$api${id != null ? "/$id" : ""}");
//     get(url).then((response) {
//       if (response.statusCode == 200) {
//         final result = jsonDecode(response.body);
//         product = Product.fromJson(result);
//         isLoading = true;
//       }
//       setState(() {});
//     });
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: isLoading
//           ? Column(
//               crossAxisAlignment: CrossAxisAlignment.stretch,
//               mainAxisAlignment: MainAxisAlignment.center,
//               children: [
//                 Flexible(child: Image.network(product!.image)),
//                 Flexible(
//                   child: Container(
//                     alignment: Alignment.topLeft,
//                     margin: const EdgeInsets.symmetric(horizontal: 20),
//                     child: Column(
//                       crossAxisAlignment: CrossAxisAlignment.start,
//                       children: [
//                         const SizedBox(height: 10),
//                         Text(
//                           product!.title,
//                           style: const TextStyle(
//                             fontSize: 30,
//                             fontWeight: FontWeight.w500,
//                           ),
//                         ),
//                         const SizedBox(height: 10),
//                         Row(
//                           mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                           children: [
//                             Text(
//                               product!.price.toString(),
//                               style: const TextStyle(
//                                 fontWeight: FontWeight.w700,
//                                 fontSize: 30,
//                               ),
//                             ),
//                             const Text(
//                               "Price",
//                               style: TextStyle(
//                                 fontSize: 25,
//                                 fontWeight: FontWeight.w700,
//                               ),
//                             ),
//                           ],
//                         ),
//                         const SizedBox(height: 20),
//                         Row(
//                           mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                           children: [
//                             Icon(
//                               Icons.star,
//                               color: Colors.yellow.shade700,
//                             ),
//                             const SizedBox(width: 10),
//                             const Text(
//                               "3.9",
//                               style: TextStyle(
//                                 fontSize: 18,
//                                 fontWeight: FontWeight.w700,
//                               ),
//                             ),
//                             const SizedBox(width: 30),
//                             const Text(
//                               "50 reviews",
//                               style: TextStyle(
//                                 fontSize: 14,
//                                 fontWeight: FontWeight.w600,
//                                 color: Colors.grey,
//                               ),
//                             ),
//                           ],
//                         ),
//                         Text(product!.description),
//                         const Spacer(),
//                         Row(
//                           mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                           children: [
//                             Container(
//                               decoration: BoxDecoration(
//                                 borderRadius: BorderRadius.circular(15),
//                                 color: Colors.grey,
//                               ),
//                               height: 60,
//                               width: 60,
//                               alignment: Alignment.center,
//                               child: const Icon(Icons.bookmark_add_outlined),
//                             ),
//                             Container(
//                               alignment: Alignment.center,
//                               decoration: BoxDecoration(
//                                 borderRadius: BorderRadius.circular(15),
//                                 color: Colors.black,
//                               ),
//                               height: 60,
//                               width: 280,
//                               child: const Text(
//                                 "Add to cart",
//                                 style: TextStyle(
//                                   fontSize: 20,
//                                   color: Colors.white,
//                                 ),
//                               ),
//                             ),
//                           ],
//                         ),
//                         const SizedBox(height: 30),
//                       ],
//                     ),
//                   ),
//                 ),
//               ],
//             )
//           : const CircularProgressIndicator(),
//     );
//   }
// }

/// #Snapshot 2
// class HomePageSecondLesson extends StatefulWidget {
//   const HomePageSecondLesson({Key? key}) : super(key: key);
//
//   @override
//   State<HomePageSecondLesson> createState() => _HomePageSecondLessonState();
// }
//
// class _HomePageSecondLessonState extends State<HomePageSecondLesson> {
//   Post? post;
//   Product? product;
//   final domain = "fakestoreapi.com";
//   final api = "/products";
//   bool isLoading = false;
//
//   @override
//   void initState() {
//     super.initState();
//     getDataFromCloud(api: api, id: 1);
//   }
//
//   void getDataFromCloud({
//     required String api,
//     String baseUrl = "fakestoreapi.com",
//     int? id,
//   }) {
//     Uri url = Uri.https(baseUrl, "$api${id != null ? "/$id" : ""}");
//     get(url).then((response) {
//       if (response.statusCode == 200) {
//         final result = jsonDecode(response.body);
//         product = Product.fromJson(result);
//         isLoading = true;
//       }
//       setState(() {});
//     });
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     double y = MediaQuery.of(context).size.height;
//     double x = MediaQuery.of(context).size.width;
//
//     return Scaffold(
//       body: isLoading
//           ? Column(
//               crossAxisAlignment: CrossAxisAlignment.stretch,
//               mainAxisAlignment: MainAxisAlignment.center,
//               children: [
//                 SizedBox(
//                   height: y * 0.5,
//                   child: Image.network(
//                     product!.image,
//                     fit: BoxFit.contain,
//                   ),
//                 ),
//                 Container(
//                   height: y * 0.5,
//                   width: x,
//                   alignment: Alignment.topLeft,
//                   margin: const EdgeInsets.symmetric(horizontal: 20),
//                   child: Column(
//                     crossAxisAlignment: CrossAxisAlignment.start,
//                     children: [
//                       const SizedBox(height: 10),
//                       Text(
//                         product!.title,
//                         style: const TextStyle(
//                           fontSize: 30,
//                           fontWeight: FontWeight.w500,
//                         ),
//                       ),
//                       const SizedBox(height: 10),
//                       Row(
//                         mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                         children: [
//                           Text(
//                             product!.price.toString(),
//                             style: const TextStyle(
//                               fontWeight: FontWeight.w700,
//                               fontSize: 30,
//                             ),
//                           ),
//                           const Text(
//                             "Price",
//                             style: TextStyle(
//                               fontSize: 25,
//                               fontWeight: FontWeight.w700,
//                             ),
//                           ),
//                         ],
//                       ),
//                       const SizedBox(height: 20),
//                       Row(
//                         mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                         children: [
//                           Icon(
//                             Icons.star,
//                             color: Colors.yellow.shade700,
//                           ),
//                           const SizedBox(width: 10),
//                           const Text(
//                             "3.9",
//                             style: TextStyle(
//                               fontSize: 18,
//                               fontWeight: FontWeight.w700,
//                             ),
//                           ),
//                           const SizedBox(width: 30),
//                           const Text(
//                             "50 reviews",
//                             style: TextStyle(
//                               fontSize: 14,
//                               fontWeight: FontWeight.w600,
//                               color: Colors.grey,
//                             ),
//                           ),
//                         ],
//                       ),
//                       const SizedBox(height: 30),
//                       Text(product!.description),
//                       const Spacer(),
//                       Row(
//                         mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                         children: [
//                           Container(
//                             decoration: BoxDecoration(
//                               borderRadius: BorderRadius.circular(15),
//                               color: Colors.grey,
//                             ),
//                             height: 60,
//                             width: 60,
//                             alignment: Alignment.center,
//                             child: const Icon(Icons.bookmark_add_outlined),
//                           ),
//                           Container(
//                             alignment: Alignment.center,
//                             decoration: BoxDecoration(
//                               borderRadius: BorderRadius.circular(15),
//                               color: Colors.black,
//                             ),
//                             height: 60,
//                             width: 280,
//                             child: const Text(
//                               "Add to cart",
//                               style: TextStyle(
//                                 fontSize: 20,
//                                 color: Colors.white,
//                               ),
//                             ),
//                           ),
//                         ],
//                       ),
//                       const SizedBox(height: 30),
//                     ],
//                   ),
//                 ),
//               ],
//             )
//           : const Center(child: CircularProgressIndicator()),
//     );
//   }
// }

/// #Snapshot 3
// class SecondHomePage extends StatefulWidget {
//   const SecondHomePage({Key? key}) : super(key: key);
//
//   @override
//   State<SecondHomePage> createState() => _SecondHomePageState();
// }
//
// class _SecondHomePageState extends State<SecondHomePage> {
//   List<Post> list = [];
//   final domain = "jsonplaceholder.typicode.com";
//   final api = "/posts";
//
//   @override
//   void initState() {
//     super.initState();
//     getDataFromCloud(api: api);
//   }
//
//   void getDataFromCloud({
//     required String api,
//     String baseUrl = "jsonplaceholder.typicode.com",
//     int? id,
//   }) {
//     Uri url = Uri.https(baseUrl, "$api${id != null ? "/$id" : ""}");
//     get(url).then((response) {
//       if (response.statusCode == 200) {
//         final List result = jsonDecode(response.body);
//         for (int i = 0; i < result.length; i++) {
//           debugPrint(result[i].toString());
//           final post = Post.fromJson(result[i]);
//           list.add(post);
//         }
//       }
//       setState(() {});
//     });
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: const Text("User Posts"),
//       ),
//       body: ListView.builder(
//         itemCount: list.length,
//         itemBuilder: (_, index) {
//           final post = list[index];
//           return Card(
//             child: ListTile(
//               leading: Container(
//                 padding: const EdgeInsets.all(10),
//                 decoration: BoxDecoration(
//                   shape: BoxShape.circle,
//                   color: Colors.primaries[index % Colors.primaries.length],
//                 ),
//                 child: Text(
//                   post.userId.toString(),
//                   style: const TextStyle(
//                     color: Colors.white,
//                     fontSize: 16,
//                   ),
//                 ),
//               ),
//               title: Text(post.title),
//               subtitle: Text(post.body),
//             ),
//           );
//         },
//       ),
//     );
//   }
// }

/// #Snapshot 4
// class SecondHomePage extends StatefulWidget {
//   const SecondHomePage({Key? key}) : super(key: key);
//
//   @override
//   State<SecondHomePage> createState() => _SecondHomePageState();
// }
//
// class _SecondHomePageState extends State<SecondHomePage> {
//   List<Todo> list = [];
//   final domain = "dummyjson.com";
//   final api = "/posts";
//   final apiTodos = "/todos";
//
//   @override
//   void initState() {
//     super.initState();
//     getDataFromCloud(api: apiTodos);
//   }
//
//   void getDataFromCloud({
//     required String api,
//     String baseUrl = "dummyjson.com",
//     int? id,
//   }) {
//     Uri url = Uri.https(baseUrl, "$api${id != null ? "/$id" : ""}");
//     get(url).then((response) {
//       if (response.statusCode == 200) {
//         final result = jsonDecode(response.body);
//
//         debugPrint(result.toString());
//         debugPrint(result["todos"].toString());
//
//         for (int i = 0; i < result["todos"].length; i++) {
//           final todo = Todo.fromJson(result["todos"][i]);
//           list.add(todo);
//         }
//       }
//       setState(() {});
//     });
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: const Text("User Posts"),
//       ),
//       body: ListView.builder(
//         itemCount: list.length,
//         itemBuilder: (_, index) {
//           final todo = list[index];
//           return Card(
//             child: ListTile(
//               leading: Container(
//                 padding: const EdgeInsets.all(10),
//                 decoration: BoxDecoration(
//                   shape: BoxShape.circle,
//                   color: Colors.primaries[index % Colors.primaries.length],
//                 ),
//                 child: Text(
//                   todo.userId.toString(),
//                   style: const TextStyle(
//                     color: Colors.white,
//                     fontSize: 16,
//                   ),
//                 ),
//               ),
//               title: Text(todo.todo),
//               subtitle: Text(todo.completed.toString()),
//             ),
//           );
//         },
//       ),
//     );
//   }
// }

/// #Snapshot 8
// class SecondHomePage extends StatefulWidget {
//   const SecondHomePage({Key? key}) : super(key: key);
//
//   @override
//   State<SecondHomePage> createState() => _SecondHomePageState();
// }
//
// class _SecondHomePageState extends State<SecondHomePage> {
//   List<Post> list = [];
//   final domain = "jsonplaceholder.typicode.com";
//   final api = "/posts";
//
//   @override
//   void initState() {
//     super.initState();
//     fetchData();
//   }
//
//   void fetchData() async {
//     String data = await getMethod(api: api);
//     list = parsePostList(data);
//     setState(() {});
//   }
//
//   Future<String> getMethod({
//     required String api,
//     String baseUrl = "jsonplaceholder.typicode.com",
//     int? id,
//   }) async {
//     Uri url = Uri.https(baseUrl, "$api ${id != null ? "/$id" : ""}");
//     final response = await get(url);
//
//     if(response.statusCode == 200){
//       return response.body;
//     }
//
//     throw Exception("Network Exception");
//   }
//
//
//   List<Post> parsePostList(String data){
//     final List result = jsonDecode(data);
//     final items = result.map((json) => Post.fromJson(json)).toList();
//     return items;
//   }
//
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: const Text("User Posts"),
//       ),
//       body: ListView.builder(
//         itemCount: list.length,
//         itemBuilder: (_, index) {
//           final post = list[index];
//           return Card(
//             child: ListTile(
//               leading: Container(
//                 padding: const EdgeInsets.all(10),
//                 decoration: BoxDecoration(
//                   shape: BoxShape.circle,
//                   color: Colors.primaries[index % Colors.primaries.length],
//                 ),
//                 child: Text(
//                   post.userId.toString(),
//                   style: const TextStyle(
//                     color: Colors.white,
//                     fontSize: 16,
//                   ),
//                 ),
//               ),
//               title: Text(post.title),
//               subtitle: Text(post.body),
//             ),
//           );
//         },
//       ),
//     );
//   }
// }

/// #Snapshot 9
// class SecondHomePage extends StatefulWidget {
//   const SecondHomePage({Key? key}) : super(key: key);
//
//   @override
//   State<SecondHomePage> createState() => _SecondHomePageState();
// }
//
// class _SecondHomePageState extends State<SecondHomePage> {
//   List<Post> list = [];
//
//   @override
//   void initState() {
//     super.initState();
//     fetchData();
//   }
//
//   Future<String> getMethod({
//     required String api,
//     String baseUrl = "jsonplaceholder.typicode.com",
//     int? id,
//   }) async {
//     Uri url = Uri.https(baseUrl, "$api ${id != null ? "/$id" : ""}");
//     final response = await get(url);
//
//     if (response.statusCode == 200) {
//       return response.body;
//     }
//
//     throw Exception("Network Exception");
//   }
//
//   List<Post> parsePostList(String data) {
//     final List result = jsonDecode(data);
//     final items = result.map((json) => Post.fromJson(json)).toList();
//     return items;
//   }
//
//   void fetchData() async {
//     String? data = await Network.methodGet(api: Network.apiPosts);
//     if (data != null) {
//       list = parsePostList(data);
//       setState(() {});
//     } else {
//       ScaffoldMessenger.of(context).showSnackBar(
//         const SnackBar(
//           content: Text("Check your network!"),
//         ),
//       );
//     }
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: const Text("User Posts"),
//       ),
//       body: ListView.builder(
//         itemCount: list.length,
//         itemBuilder: (_, index) {
//           final post = list[index];
//           return Card(
//             child: ListTile(
//               leading: Container(
//                 padding: const EdgeInsets.all(10),
//                 decoration: BoxDecoration(
//                   shape: BoxShape.circle,
//                   color: Colors.primaries[index % Colors.primaries.length],
//                 ),
//                 child: Text(
//                   post.userId.toString(),
//                   style: const TextStyle(
//                     color: Colors.white,
//                     fontSize: 16,
//                   ),
//                 ),
//               ),
//               title: Text(post.title),
//               subtitle: Text(post.body),
//             ),
//           );
//         },
//       ),
//     );
//   }
// }
