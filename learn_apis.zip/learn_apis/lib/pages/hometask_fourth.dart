import 'package:flutter/material.dart';

import 'package:flutter/material.dart';
import 'package:learn_apis/models/movie_model.dart';

import '../models/big_products_model.dart';
import '../services/network_service.dart';


class Task4 extends StatefulWidget {
  const Task4({Key? key}) : super(key: key);

  @override
  State<Task4> createState() => _Task4State();
}

class _Task4State extends State<Task4> {
  List<Movie> list = [];

  @override
  void initState() {
    super.initState();
    fetchData();
  }

  void fetchData() async {
    String? data = await Network.methodGetMovies(api: Network.apiMovies);
    if (data != null) {
      list = Network.parseMovieList(data);
      setState(() {});
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("Check Your Network!!!"),
        ),
      );
    }
  }


  @override
  Widget build(BuildContext context) {
    return  Scaffold(
      body: ListView.builder(
        itemCount: list.length,
        itemBuilder: (_, index) {
          final movies = list[index];
          return Card(
            child: ListTile(
              leading: Text(
                movies.id.toString(),
                style: const TextStyle(
                  color: Colors.black,
                  fontSize: 16,
                  fontWeight: FontWeight.w500,
                ),
              ),
              title: Container(
                padding: const EdgeInsets.all(10),
                child: Text(
                  movies.movie,
                  style: const TextStyle(
                    color: Colors.black,
                    fontSize: 16,
                  ),
                ),
              ),
              subtitle: Text(
                movies.rating.toString(),
                style: const TextStyle(
                  color: Colors.black,
                  fontSize: 16,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}

