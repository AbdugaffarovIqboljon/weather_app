import 'package:flutter/material.dart';

import '../models/big_products_model.dart';


class Task3 extends StatefulWidget {
  const Task3({Key? key}) : super(key: key);

  @override
  State<Task3> createState() => _Task3State();
}

class _Task3State extends State<Task3> {
  final List<BigProduct> list = [];

  

  @override
  Widget build(BuildContext context) {
    return Scaffold(

    );
  }
}
