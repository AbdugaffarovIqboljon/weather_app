import 'package:flutter/material.dart';
import 'package:learn_apis/pages/hometask_fourth.dart';
import 'package:learn_apis/services/network_service.dart';

import '../models/quotes_model.dart';
import 'hometask_third.dart';
import 'homework_task_second.dart';

class Task1 extends StatefulWidget {
  const Task1({Key? key}) : super(key: key);

  @override
  State<Task1> createState() => _Task1State();
}

class _Task1State extends State<Task1> {
  List<Quotes> list = [];

  @override
  void initState() {
    super.initState();
    fetchData();
  }

  void fetchData() async {
    String? data = await Network.methodGetQuotes(api: Network.apiQuotes);
    if (data != null) {
      list = Network.parseQuotesList(data);
      setState(() {});
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("Check Your Network!!!"),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    PageController controller = PageController();
    return Scaffold(
      appBar: AppBar(
        title: const Text("User Posts"),
      ),
      body: PageView(
        physics: const ScrollPhysics(),
        scrollDirection: Axis.horizontal,
        controller: controller,
        onPageChanged: (index){
          controller.jumpToPage(index);
        },
        children: [
          ListView.builder(
            itemCount: list.length,
            itemBuilder: (_, index) {
              final quotes = list[index];
              return Card(
                child: ListTile(
                  leading: Text(
                    quotes.id.toString(),
                    style: const TextStyle(
                      color: Colors.black,
                      fontSize: 16,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  title: Container(
                    padding: const EdgeInsets.all(10),
                    child: Text(
                      quotes.quote,
                      style: const TextStyle(
                        color: Colors.black,
                        fontSize: 16,
                      ),
                    ),
                  ),
                  subtitle: Text(
                    quotes.author,
                    style: const TextStyle(
                      color: Colors.black,
                      fontSize: 16,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
              );
            },
          ),
          const Task2(),
          const Task4(),
        ],
      ),
    );
  }
}
