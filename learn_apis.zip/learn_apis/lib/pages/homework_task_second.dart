import 'package:flutter/material.dart';

import '../models/small_products_model.dart';
import '../services/network_service.dart';

class Task2 extends StatefulWidget {
  const Task2({Key? key}) : super(key: key);

  @override
  State<Task2> createState() => _Task2State();
}

class _Task2State extends State<Task2> {
  List<SmallProduct> list = [];

  @override
  void initState() {
    super.initState();
    fetchData();
  }

  void fetchData() async {
    String? data = await Network.methodGetSmallProducts(api: Network.apiProducts);
    if (data != null) {
      list = Network.parseSmallProductsLists(data);
      setState(() {});
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("Check Your Network!!!"),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: ListView.builder(
        itemCount: list.length,
        itemBuilder: (_, index) {
          final products = list[index];
          return Card(
            child: ListTile(
              leading: Text(
                products.id.toString(),
                style: const TextStyle(
                  color: Colors.black,
                  fontSize: 16,
                  fontWeight: FontWeight.w500,
                ),
              ),
              title: Container(
                padding: const EdgeInsets.all(10),
                child: Text(
                  products.name,
                  style: const TextStyle(
                    color: Colors.black,
                    fontSize: 16,
                  ),
                ),
              ),
              subtitle: Text(
                products.description,
                style: const TextStyle(
                  color: Colors.black,
                  fontSize: 16,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
