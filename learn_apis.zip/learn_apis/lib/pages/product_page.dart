import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart';
import 'package:learn_apis/models/product_model.dart';

class ProductPage extends StatefulWidget {
  const ProductPage({Key? key}) : super(key: key);

  @override
  State<ProductPage> createState() => _ProductPageState();
}

class _ProductPageState extends State<ProductPage> {
  Product? product;
  final domain = "fakestoreapi.com";
  final api = "/products";

  @override
  void initState() {
    getDataFromCloud(api: api, id: 1);
    super.initState();
  }

  void getDataFromCloud({
    required String api,
    String baseUrl = "fakestoreapi.com",
    int? id,
  }) {
    Uri url = Uri.https(baseUrl, "$api${id != null ? "/$id" : ""}");
    get(url).then((response) {
      if (response.statusCode == 200) {
        final result = jsonDecode(response.body);
        product = Product.fromJson(result);
      }
      setState(() {});
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: product != null
            ? Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12),
                child: Container(
                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.brown),
                    borderRadius: const BorderRadius.all(
                      Radius.circular(15),
                    ),
                    color: Colors.brown.shade100,
                  ),
                  child: ListTile(
                    minVerticalPadding: 20,
                    title: FittedBox(
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          Text(product!.title),
                        ],
                      ),
                    ),
                    subtitle: Padding(
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      child: Text(product!.description),
                    ),
                    trailing: Padding(
                      padding: const EdgeInsets.symmetric(vertical: 3),
                      child: Text(
                        "${product!.price} \$",
                        style: const TextStyle(
                          fontSize: 12,
                          color: Colors.black,
                        ),
                      ),
                    ),
                    leading: Transform.translate(
                      offset: const Offset(0, 20),
                      filterQuality: FilterQuality.high,
                      child: Image.network(
                        product!.image,
                        width: 55,
                        height: 55,
                      ),
                    ),
                  ),
                ),
              )
            : const Text("NO DATA"),
      ),
    );
  }
}
