import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:http/http.dart';
import 'package:learn_apis/models/photo_model.dart';

import '../models/big_products_model.dart';
import '../models/movie_model.dart';
import '../models/post_model.dart';
import '../models/quotes_model.dart';
import '../models/small_products_model.dart';

class Network {
  /// DOMAIN
  static const baseUrl = "jsonplaceholder.typicode.com";
  static const secondUrl = "dummyjson.com";
  static const thirdUrl = "hub.dummyapis.com";
  static const fourthUrl = "dummyapi.online";

  /// APIS
  static const apiPosts = "/posts";
  static const apiTodos = "/todos";
  static const apiUsers = "/users";
  static const apiAlbums = "/albums";
  static const apiComments = "/comments";
  static const apiPhotos = "/photos";
  static const apiQuotes = "/quotes";
  static const apiProducts = "/products";
  static const apiMovies = "/api/movies";

  /// METHODS
  static Future<String?> methodGetSmallProducts({required String api, int? id}) async {
    Uri url = Uri.https(thirdUrl, "$api${id != null ? "/$id" : ""}");
    try {
      final response = await get(url);

      if (response.statusCode == 200) {
        return response.body;
      }
    } catch (e) {
      debugPrint(e.toString());
      return null;
    }
  }

  static Future<String?> methodGetQuotes({required String api, int? id}) async {
    Uri url = Uri.https(secondUrl, "$api${id != null ? "/$id" : ""}");
    try {
      final response = await get(url);

      if (response.statusCode == 200) {
        return response.body;
      }
    } catch (e) {
      debugPrint(e.toString());
      return null;
    }
  }

  static Future<String?> methodGetMovies({required String api, int? id}) async {
    Uri url = Uri.https(fourthUrl, "$api${id != null ? "/$id" : ""}");
    try {
      final response = await get(url);

      if (response.statusCode == 200) {
        return response.body;
      }
    } catch (e) {
      debugPrint(e.toString());
      return null;
    }
  }

  /// PARSING

  /// #Posts
  static List<Post> parsePostList(String data) {
    final List result = jsonDecode(data);
    final items = result.map((json) => Post.fromJson(json)).toList();
    return items;
  }

  /// #Albums
  static List<Photo> parseAlbumList(String data) {
    final List result = jsonDecode(data);
    final items = result.map((json) => Photo.fromJson(json)).toList();
    return items;
  }

  /// #Quotes
  static List<Quotes> parseQuotesList(String data) {
    final List result = jsonDecode(data)["quotes"];
    final items = result.map((json) => Quotes.fromJson(json)).toList();
    return items;
  }

  /// #SmallProducts
  static List<SmallProduct> parseSmallProductsLists(String data) {
    final List result = jsonDecode(data);
    final items = result.map((json) => SmallProduct.fromJson(json)).toList();
    return items;
  }

  /// #Big Product
  static List<BigProduct> parseBigProductList(String data) {
    final result = jsonDecode(data)["products"];
    final items = result.map((json) => BigProduct.fromJson(json)).toList();
    return items;
  }

  /// #Movie
  static List<Movie> parseMovieList(String data) {
    final result = jsonDecode(data)["movies"];
    final items = result.map((json) => Movie.fromJson(json)).toList();
    return items;
  }
}




