import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:weather_app/screens/first_splash_page.dart';

// void main() {
//   runApp(const MaterialApp(
//     home: MapPage(),
//   ));
// }

void main() => runApp(const SplashPageOne());
