import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class BottomMenu extends StatelessWidget {
  final void Function(int value) onChanged;
  final int index;

  const BottomMenu({super.key, required this.onChanged, this.index = 0});

  @override
  Widget build(BuildContext context) {
    int page = index;
    return BottomAppBar(
      color: Colors.white,
      padding: const EdgeInsets.only(left: 30, right: 30),
      elevation: 0,
      height: 70,
      child: Row(
        children: [
          const Spacer(),
          ElevatedButton(
            onPressed: () {
              onChanged(0);
            },
            style: ButtonStyle(
              elevation: MaterialStateProperty.all(0),
              fixedSize: MaterialStateProperty.all(const Size(64, 50)),
              shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
              ),
              backgroundColor: MaterialStateProperty.all(
                page == 0 ? const Color(0XFF0C1823) : Colors.white,
              ),
            ),
            child: Icon(
              CupertinoIcons.sun_max,
              color: page == 0 ? Colors.white : Colors.black,
            ),
          ),
          const Spacer(),
          ElevatedButton(
            onPressed: () {
              onChanged(1);
            },
            style: ButtonStyle(
              elevation: MaterialStateProperty.all(0),
              fixedSize: MaterialStateProperty.all(const Size(64, 50)),
              shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
              ),
              backgroundColor: MaterialStateProperty.all(
                page == 1 ? const Color(0XFF0C1823) : Colors.white,
              ),
            ),
            child: Image.asset(
              "assets/icons/ic_cloud_nav_bar.png",
              color: page == 1 ? Colors.white : Colors.black,
            ),
          ),
          const Spacer(),
          ElevatedButton(
            onPressed: () {
              onChanged(2);
            },
            style: ButtonStyle(
              elevation: MaterialStateProperty.all(0),
              fixedSize: MaterialStateProperty.all(
                const Size(64, 50),
              ),
              shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
              ),
              backgroundColor: MaterialStateProperty.all(
                  page == 2 ? const Color(0XFF0C1823) : Colors.white),
            ),
            child: Icon(
              Icons.location_on_outlined,
              color: page == 2 ? Colors.white : Colors.black,
            ),
          ),
          const Spacer(),
          ElevatedButton(
            onPressed: () {
              onChanged(3);
            },
            style: ButtonStyle(
              elevation: MaterialStateProperty.all(0),
              fixedSize: MaterialStateProperty.all(
                const Size(64, 50),
              ),
              shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
              ),
              backgroundColor: MaterialStateProperty.all(
                  page == 3 ? const Color(0XFF0C1823) : Colors.white),
            ),
            child: Image.asset(
              "assets/icons/ic_thunder_bottom_nav_bar.png",
              color: page == 3 ? Colors.white : Colors.black,
            ),
          ),
          const Spacer(),
        ],
      ),
    );
  }
}
