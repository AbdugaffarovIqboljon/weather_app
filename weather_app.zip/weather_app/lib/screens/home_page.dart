import 'package:flutter/material.dart';
import 'package:weather_app/screens/error_404_page.dart';
import 'package:weather_app/screens/maps_page.dart';
import 'package:weather_app/screens/mood_asking_page.dart';
import 'package:weather_app/screens/settings_page.dart';
import 'bottom_nav_bar.dart';


class Home extends StatelessWidget {
  const Home({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  PageController pageController = PageController();
  int page = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      bottomNavigationBar: BottomMenu(
        index: page,
        onChanged: (page) {
          pageController.jumpToPage(page);
          pageController.animateToPage(page,
              duration: const Duration(seconds: 1), curve: Curves.linear);
        },
      ),
      body: PageView(
        controller: pageController,
        onPageChanged: (newPage) {
          setState(() {});
          page = newPage;
        },
        children: [
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.only(left: 25, right: 25, top: 20),
              child: Column(
                children: [
                  Row(
                    children: [
                      Image.asset(
                        "assets/images/profile_photo.png",
                        height: 38,
                        width: 40,
                        scale: 2.9,
                      ),
                      const Spacer(flex: 2),
                      SizedBox(
                        width: 123,
                        height: 60,
                        child: Column(
                          children: [
                            const Spacer(),
                            const Align(
                              alignment: Alignment.centerLeft,
                              child: Text(
                                "Britney Glayers",
                                style: TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.w400,
                                  fontFamily: "Poppins",
                                ),
                              ),
                            ),
                            const Spacer(),
                            Align(
                              alignment: Alignment.centerLeft,
                              child: Row(
                                children: const [
                                  Text(
                                    "New York-USA",
                                    style: TextStyle(
                                        fontSize: 12,
                                        fontWeight: FontWeight.w400,
                                        fontFamily: "Poppins"),
                                  ),
                                  Icon(
                                    Icons.keyboard_arrow_down,
                                    weight: 13,
                                  )
                                ],
                              ),
                            ),
                            const Spacer(),
                          ],
                        ),
                      ),
                      const Spacer(flex: 18),
                      Image.asset(
                        "assets/icons/ic_dashboard.png",
                        width: 32,
                        height: 32,
                        scale: 0.9,
                      ),
                    ],
                  ),
                  const Spacer(flex: 2),
                  Padding(
                    padding: const EdgeInsets.only(left: 20),
                    child: Row(
                      children: [
                        const SizedBox(
                          width: 220,
                          height: 62,
                          child: Text(
                            "Feels like A good time to ride a bike",
                            style: TextStyle(
                              fontSize: 24,
                              fontWeight: FontWeight.w500,
                              fontFamily: "Poppins",
                            ),
                          ),
                        ),
                        const Spacer(),
                        Image.asset("assets/icons/ic_bike.png",
                            height: 32, width: 32),
                        const Spacer(flex: 10),
                      ],
                    ),
                  ),
                  const Spacer(flex: 2),
                  Container(
                    alignment: Alignment.center,
                    height: 374,
                    width: 374,
                    child: Stack(
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(left: 20),
                          child: Container(
                            alignment: Alignment.center,
                            padding: const EdgeInsets.only(
                              top: 80,
                              right: 40,
                            ),
                            height: 264,
                            width: 264,
                            decoration: BoxDecoration(
                                color: const Color(0XFF0C1823),
                                borderRadius: BorderRadius.circular(264)),
                            child: Column(
                              children: const [
                                Text(
                                  "Today's like",
                                  style: TextStyle(
                                      color: Color(0XFFFFFFFF),
                                      fontFamily: "Poppins",
                                      fontSize: 15,
                                      fontWeight: FontWeight.w400),
                                ),
                                Text(
                                  "25°",
                                  style: TextStyle(
                                    fontWeight: FontWeight.w400,
                                    fontFamily: "Poppins",
                                    color: Colors.white,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(top: 20, left: 20),
                          child: Image.asset(
                            "assets/icons/ic_cloudy_day_icon.png",
                            height: 75,
                            width: 75,
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(left: 200, top: 10),
                          child: Image.asset(
                            "assets/icons/ic_rain_icon.png",
                            height: 65,
                            width: 65,
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(top: 130, left: 10),
                          child: Image.asset(
                            "assets/icons/ic_windy_icon.png",
                            height: 75,
                            width: 75,
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(top: 160, left: 220),
                          child: Image.asset(
                            "assets/icons/ic_clear_night_icon.png",
                            width: 75,
                            height: 75,
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(top: 210, left: 110),
                          child: Image.asset(
                            "assets/icons/ic_thundersrtom_icon.png",
                            height: 75,
                            width: 75,
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(top: 100, left: 130),
                          child: Image.asset(
                            "assets/icons/ic_sunny_weather.png",
                            height: 84,
                            width: 85,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const Spacer(flex: 4),
                  Padding(
                    padding: const EdgeInsets.only(right: 30),
                    child: Row(
                      children: [
                        const Spacer(),
                        Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: const [
                            SizedBox(
                              child: Text(
                                "Today's Mood",
                                style: TextStyle(
                                  fontSize: 14.02,
                                  fontFamily: "Poppins",
                                  fontWeight: FontWeight.w400,
                                ),
                              ),
                            ),
                            SizedBox(
                              child: Text(
                                "Very Good",
                                style: TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.w500,
                                  fontFamily: "Poppins",
                                ),
                              ),
                            ),
                          ],
                        ),
                        const Spacer(),
                        Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: const [
                            SizedBox(
                              child: Text(
                                "Tomorrow's Mood",
                                style: TextStyle(
                                  fontSize: 14.02,
                                  fontFamily: "Poppins",
                                  fontWeight: FontWeight.w400,
                                ),
                              ),
                            ),
                            SizedBox(
                              child: Text(
                                "Excellent",
                                style: TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.w500,
                                  fontFamily: "Poppins",
                                ),
                              ),
                            ),
                          ],
                        ),
                        const Spacer(),
                      ],
                    ),
                  ),
                  const Spacer(flex: 8),
                ],
              ),
            ),
          ),
          const MoodAskingPage(),
          const MapPage(),
          const SettingsPage(),
          const ErrorPage(),
          // const MyApp5(),
          // const MyApp6(),
        ],
      ),
    );
  }
}
