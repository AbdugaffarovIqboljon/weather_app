import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class MapPage extends StatefulWidget {
  const MapPage({super.key});

  @override
  State<MapPage> createState() => _MapPageState();
}

class _MapPageState extends State<MapPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.only(left: 25, right: 25, top: 20),
          child: SingleChildScrollView(
            child: Column(
              children: [
                Row(
                  children: [
                    Image.asset(
                      "assets/images/profile_photo.png",
                      height: 38,
                      width: 40,
                      scale: 2.9,
                    ),
                    const Spacer(flex: 2),
                    SizedBox(
                      width: 123,
                      height: 60,
                      child: Column(
                        children: [
                          const Spacer(),
                          const Align(
                            alignment: Alignment.centerLeft,
                            child: Text(
                              "Britney Glayers",
                              style: TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.w400,
                                fontFamily: "Poppins",
                              ),
                            ),
                          ),
                          const Spacer(),
                          Align(
                            alignment: Alignment.centerLeft,
                            child: Row(
                              children: const [
                                Text(
                                  "New York-USA",
                                  style: TextStyle(
                                      fontSize: 12,
                                      fontWeight: FontWeight.w400,
                                      fontFamily: "Poppins"),
                                ),
                                Icon(
                                  Icons.keyboard_arrow_down,
                                  weight: 13,
                                )
                              ],
                            ),
                          ),
                          const Spacer(),
                        ],
                      ),
                    ),
                    const Spacer(flex: 18),
                    Image.asset(
                      "assets/icons/ic_dashboard.png",
                      width: 32,
                      height: 32,
                      scale: 0.9,
                    ),
                  ],
                ),
                const SizedBox(height: 60),
                TextField(
                  decoration: InputDecoration(
                    suffixIcon: const Icon(CupertinoIcons.search),
                    hintText: "Bosila, Mohammadpur Dhaka",
                    hintStyle: const TextStyle(
                      fontWeight: FontWeight.w400,
                      fontSize: 12,
                      color: Color.fromRGBO(54, 66, 77, 1),
                      fontFamily: "Poppins",
                    ),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                ),
                const SizedBox(height: 30),
                Stack(
                  children: [
                    Container(
                      height: 500,
                      width: 350,
                      decoration: BoxDecoration(
                        image: const DecorationImage(
                          image: AssetImage("assets/images/img_base_map.png"),
                          isAntiAlias: true,
                        ),
                        borderRadius: BorderRadius.circular(25),
                      ),
                    ),
                    const Padding(
                      padding: EdgeInsets.only(top: 240, left: 80),
                      child: Icon(
                        Icons.location_on_outlined,
                        color: Color.fromRGBO(254, 58, 117, 1),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
