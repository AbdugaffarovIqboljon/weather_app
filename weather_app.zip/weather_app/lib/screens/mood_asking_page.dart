import 'package:flutter/material.dart';
import 'package:weather_app/services/constants/string_constants.dart';

class MoodAskingPage extends StatefulWidget {
  const MoodAskingPage({super.key});

  @override
  State<MoodAskingPage> createState() => _MoodAskingPageState();
}

class _MoodAskingPageState extends State<MoodAskingPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,

      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.only(left: 25, right: 25, top: 20),
          child: Column(
            children: [
              Row(
                children: [
                  Image.asset(
                    "assets/images/profile_photo.png",
                    height: 38,
                    width: 40,
                    scale: 2.9,
                  ),
                  const Spacer(flex: 2),
                  SizedBox(
                    width: 123,
                    height: 60,
                    child: Column(
                      children: [
                        const Spacer(),
                        const Align(
                          alignment: Alignment.centerLeft,
                          child: Text(
                            "Britney Glayers",
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w400,
                              fontFamily: "Poppins",
                            ),
                          ),
                        ),
                        const Spacer(),
                        Align(
                          alignment: Alignment.centerLeft,
                          child: Row(
                            children: const [
                              Text(
                                "New York-USA",
                                style: TextStyle(
                                    fontSize: 12,
                                    fontWeight: FontWeight.w400,
                                    fontFamily: "Poppins"),
                              ),
                              Icon(
                                Icons.keyboard_arrow_down,
                                weight: 13,
                              )
                            ],
                          ),
                        ),
                        const Spacer(),
                      ],
                    ),
                  ),
                  const Spacer(flex: 18),
                  Image.asset(
                    "assets/icons/ic_dashboard.png",
                    width: 32,
                    height: 32,
                    scale: 0.9,
                  ),
                ],
              ),
              const Spacer(flex: 2),
              Padding(
                padding: const EdgeInsets.only(left: 20),
                child: Row(
                  children: const [
                    SizedBox(
                      width: 220,
                      height: 62,
                      child: Text(
                        "How you feel Today ?",
                        style: TextStyle(
                          fontSize: 24,
                          fontWeight: FontWeight.w500,
                          fontFamily: "Poppins",
                          color: Color.fromRGBO(9, 21, 30, 1),
                        ),
                      ),
                    ),
                    Spacer(flex: 10),
                  ],
                ),
              ),
              const Spacer(flex: 2),
              Column(
                children: [
                  Row(
                    children: const [
                      MyOutlinedButton(text: StringConstants.veryGood),
                      Spacer(),
                      MyOutlinedButton(text: StringConstants.okish),
                      Spacer(flex: 4),
                    ],
                  ),
                  const SizedBox(height: 20),
                  Row(
                    children: const [
                      MyOutlinedButton(text: StringConstants.veryBad),
                      Spacer(),
                      MyOutlinedButton(text: StringConstants.angry),
                      Spacer(flex: 4),
                    ],
                  ),
                  const SizedBox(height: 20),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: const [
                      MyOutlinedButton(
                          text: StringConstants.justSadForNoReason),
                    ],
                  ),
                  const SizedBox(height: 20),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: const [
                      MyOutlinedButton(text: StringConstants.veryHappy),
                    ],
                  ),
                ],
              ),
              const Spacer(flex: 4),
              Padding(
                padding: const EdgeInsets.only(right: 30),
                child: Row(
                  children: [
                    const Spacer(),
                    Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: const [
                        SizedBox(
                          child: Text(
                            "Today's Mood",
                            style: TextStyle(
                              fontSize: 14.02,
                              fontFamily: "Poppins",
                              fontWeight: FontWeight.w400,
                            ),
                          ),
                        ),
                        SizedBox(
                          child: Text(
                            "Very Good",
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w500,
                              fontFamily: "Poppins",
                            ),
                          ),
                        ),
                      ],
                    ),
                    const Spacer(),
                    Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: const [
                        SizedBox(
                          child: Text(
                            "Tomorrow's Mood",
                            style: TextStyle(
                              fontSize: 14.02,
                              fontFamily: "Poppins",
                              fontWeight: FontWeight.w400,
                            ),
                          ),
                        ),
                        SizedBox(
                          child: Text(
                            "Excellent",
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w500,
                              fontFamily: "Poppins",
                            ),
                          ),
                        ),
                      ],
                    ),
                    const Spacer(),
                  ],
                ),
              ),
              const Spacer(flex: 8),
            ],
          ),
        ),
      ),

      // const MyApp3(),
      // const MyApp4(),
      // const MyApp5(),
      // const MyApp6(),
    );
  }
}

class MyOutlinedButton extends StatelessWidget {
  final String text;

  const MyOutlinedButton({super.key, required this.text});

  @override
  Widget build(BuildContext context) {
    return OutlinedButton(
      onPressed: () {},
      style: OutlinedButton.styleFrom(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        fixedSize: const Size(double.infinity, 81),
      ),
      child: Text(
        text,
        style: const TextStyle(
          fontSize: 15,
          fontWeight: FontWeight.w500,
          color: Color.fromRGBO(54, 66, 77, 1),
        ),
      ),
    );
  }
}
